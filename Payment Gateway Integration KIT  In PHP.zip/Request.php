<html>
<head>
<title> Non-Seamless-kit</title>
</head>
<body>
<center>

<?php 
  $merchant_data='';
	$str='';
	//foreach ($_POST as $key => $value){
	//	$str.=$value.'|';
		
	$count =1;
	foreach ($_POST as $key => $value){
	if($count<22)
		$str.=$value.'|';
	else
		$str.=$value;
	$count +=1;	
	}		
	
	//echo $str;
//$checksum = hash_hmac('sha256',$str, 0, -1),'bhUiszTimODB', false);
	$checksum = hash_hmac('sha256',$str,'abdresHgrD', false);
$checksum = strtoupper($checksum);
 $merchant_data.=$str.'|'.$checksum;
  // $merchant_data.=$str.$checksum;
	 $merchant_data;
?>
<form method="post" name="redirect" action=" https://pgi.billdesk.com/pgidsk/PGIMerchantPayment"> 
<?php
echo "<input type=hidden name=msg value=$merchant_data>";

?>
</form>
</center>
<script language='javascript'>document.redirect.submit();</script>


</body>
</html>