<html>
<head>
<title> </title>
</head>
<body>
	<div style="display:none">
<center>
<form  name="redirect" method="post" action="Request.php">
			<table width="40%" height="100"  align="center" class="table" style="border:1px solid blue;">
			<center>
				<h2 style="color:green;">Payment Gateway Integration In PHP</h2>
			</center>
				<tr>
				<td></td>
				<td>
					<input type=hidden name="MerchantId" value="ABCDEFG"/>
				</td>
			</tr>
				
			<tr>
				<td>txtCustomerID	:</td>
				<td>
					<input type="text" name="txtCustomerID" value="<?php echo $_POST['trackId']; ?>"/>
				</td>
			</tr>
				 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA1" value="NA"/>
				</td>
			</tr>
			 <tr>
				<td>Amount	:</td>
				<td>
					<input type="text" name="txtTxnAmount" value="<?php echo $_POST['amount']; ?>"/>
				</td>
			</tr>
				 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA2" value="NA"/>
				</td>
			</tr>
				 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA3" value="NA"/>
				</td>
			</tr>
			
			 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA4" value="NA"/>
				</td>
			</tr>
			<tr>
				<td>CurrencyType	:</td>
				<td>
					<input type="text" name="CurrencyType" value="INR"/>
				</td>
			</tr>
					 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA5" value="NA"/>
				</td>
			</tr>
				<tr>
				<td></td>
				<td>
					<input type=hidden name="TypeField1" value="R"/>
				</td>
			</tr>
				<tr>
				<td></td>
				<td>
					<input type=hidden name="SecurityId" value="abcdefg"/>
				</td>
			</tr>
			
		 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA6" value="NA"/>
				</td>
			</tr>
					 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA7" value="NA"/>
				</td>
			</tr>
			
	 <tr>
				<td></td>
				<td>
					<input type=hidden name="TypeField2" value="<?php echo $_POST['udf2']; ?>"/>
				</td>
			</tr>
			<tr>
				<td>txtAdditionalInfo1	:</td>
				<td>
					<input type="text" name="txtAdditionalInfo1" value="<?php echo $_POST['mobile']; ?>"/>
				</td>
			</tr>
	 <tr>
				<td>txtAdditionalInfo2	:</td>
				<td>
					<input type="text" name="txtAdditionalInfo2" value="<?php echo $_POST['email']; ?>"/>
				</td>
			</tr>
		
			 <tr>
				<td></td>
				<td>
					<input type="text" name="txtAdditionalInfo3" value="123"/>
				</td>
			</tr>
			 <tr>
				<td></td>
				<td>
					<input type="text" name="txtAdditionalInfo4" value="a123"/>
				</td>
			</tr>
			 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA12" value="NA"/>
				</td>
			</tr>
			 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA8" value="NA"/>
				</td>
			</tr>
			 <tr>
				<td></td>
				<td>
					<input type=hidden name="NA9" value="NA"/>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
					<input type=hidden name="RU" value="https://domain.com/Response.php"/>
				</td>
			</tr>
					
			

			</table>
		</form>
	</center>
<script language='javascript'>document.redirect.submit();</script>

	</div>
</body>
</html>
