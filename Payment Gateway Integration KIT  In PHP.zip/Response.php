<html ng-app="ajaxExample">
<head>
		

	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.5/angular.min.js"></script>		
	</head>
	<body ng-controller="mainController">
<div >
<form name="formACS" id="formACS" action="../" method="POST" target="_parent">
			

 <?php
	
error_reporting(E_ALL);
ini_set('display_errors', '1');
	$msg=$_POST["msg"];
//echo $msg;
$str='';
$splittedstring=explode('|',$msg);
$dataSize=sizeof($splittedstring);
foreach ($splittedstring as $key => $value) {
	 "splittedstring[".$key."] = ".$value."<br>";
	
}
echo $splittedstring[1];
echo $splittedstring[23];
echo $splittedstring[24];
echo $splittedstring[25];


    

	 ?>
			
			
	</form>

		</div>
	</body>	
</html>
		   
